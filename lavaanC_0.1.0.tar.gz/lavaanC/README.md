# lavaanC

lavaanC is a free, open source R package for improving lavaan with code written in C.

